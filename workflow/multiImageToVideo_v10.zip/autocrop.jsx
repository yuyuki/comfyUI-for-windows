#target photoshop

// Ensure there's an open document
if (app.documents.length > 0) {
    var doc = app.activeDocument;

    // Check if there is an active selection
    if (doc.selection.bounds) {
        // Get the selection bounds for the face
        var bounds = doc.selection.bounds;
        var faceCenterX = (bounds[0] + bounds[2]) / 2;
        var faceCenterY = (bounds[1] + bounds[3]) / 2;
        var faceWidth = bounds[2] - bounds[0];
        var originalWidth = doc.width;
        var originalHeight = doc.height;

        // Ratios to determine crop sizes
        var ratios = [1, 0.95, 0.85, 0.75, 0.65, 0.55, 0.45]; // Including the full image first
        var crops = [];
        var cropHeights = [];

        // Calculate crop widths and heights
        for (var i = 0; i < ratios.length; i++) {
            var ratio = ratios[i];
            var cropWidth = Math.max(faceWidth * 2 * ratio, originalWidth * ratio);
            crops.push(cropWidth);
            cropHeights.push(cropWidth / (16 / 9)); // Maintain 16:9 aspect ratio
        }

        // Prompt the user to select a folder to save the images
        var folder = Folder.selectDialog("Select a folder to save the cropped images");

        if (folder) {
            for (var i = 0; i < crops.length; i++) {
                var cropWidth = crops[i];
                var cropHeight = cropHeights[i];

                // Calculate the top-left corner of the crop area
                var left = faceCenterX - cropWidth / 2;
                var top = faceCenterY - cropHeight / 2;

                // Ensure the crop stays within the image bounds
                left = Math.max(0, Math.min(left, originalWidth - cropWidth));
                top = Math.max(0, Math.min(top, originalHeight - cropHeight));

                // Duplicate the document to perform the crop
                var tempDoc = doc.duplicate();

                // Define the crop rectangle
                var cropRect = [left, top, left + cropWidth, top + cropHeight];

                // Perform the crop on the duplicated document
                tempDoc.crop(cropRect);

                // Save the cropped image
                var fileName = "/cropped_image_" + (i + 1) + ".jpg";
                var file = new File(folder.fsName + fileName);
                var saveOptions = new JPEGSaveOptions();
                saveOptions.quality = 12; // Maximum quality
                tempDoc.saveAs(file, saveOptions, true, Extension.LOWERCASE);

                // Close the duplicated document without saving changes
                tempDoc.close(SaveOptions.DONOTSAVECHANGES);
            }

            alert("All images have been cropped and saved to the selected folder.");
        } else {
            alert("No folder selected. Images were not saved.");
        }
    } else {
        alert("Please select the face area using the Marquee Tool.");
    }
} else {
    alert("Please open an image document first.");
}
