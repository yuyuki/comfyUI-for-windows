import tkinter as tk
from tkinter import filedialog, simpledialog, messagebox
from PIL import Image, ImageTk
import os

class ImageCropper:
    def __init__(self, root):
        self.root = root
        self.root.title("Image Cropper")

        # Set initial canvas size
        initial_width = 800
        initial_height = 600
        self.canvas = tk.Canvas(root, cursor="cross", width=initial_width, height=initial_height)
        self.canvas.pack(fill="both", expand=True)

        self.image_path = None
        self.original_image = None
        self.image = None
        self.tk_image = None

        self.rect = None
        self.start_x = None
        self.start_y = None
        self.end_x = None
        self.end_y = None

        self.aspect_ratio = None
        self.scaling_factor = 1.0

        self.crop_count = 0
        self.rectangles = []

        self.setup_ui()

    def setup_ui(self):
        menubar = tk.Menu(self.root)
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="Open Image", command=self.open_image)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        menubar.add_cascade(label="File", menu=file_menu)

        tools_menu = tk.Menu(menubar, tearoff=0)
        tools_menu.add_command(label="Set Aspect Ratio", command=self.set_aspect_ratio)
        menubar.add_cascade(label="Tools", menu=tools_menu)

        self.root.config(menu=menubar)

        self.canvas.bind("<ButtonPress-1>", self.on_button_press)
        self.canvas.bind("<B1-Motion>", self.on_mouse_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_button_release)
        
        # Bind Enter key to crop_image function
        self.root.bind("<Return>", lambda event: self.crop_image())

    def open_image(self):
        file_path = filedialog.askopenfilename(filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.bmp")])
        if file_path:
            self.image_path = file_path
            self.load_image()

    def calculate_scaling_factor(self, image_width, image_height, canvas_width, canvas_height, padding=20):
        width_ratio = (canvas_width - 2 * padding) / image_width
        height_ratio = (canvas_height - 2 * padding) / image_height
        return min(width_ratio, height_ratio)

    def load_image(self):
        self.original_image = Image.open(self.image_path)
        
        # Get the screen dimensions
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        
        # Calculate the scaling factor
        self.scaling_factor = self.calculate_scaling_factor(
            self.original_image.width, self.original_image.height,
            screen_width, screen_height
        )
        
        # Calculate new dimensions
        new_width = int(self.original_image.width * self.scaling_factor)
        new_height = int(self.original_image.height * self.scaling_factor)
        
        # Resize the image
        self.image = self.original_image.resize((new_width, new_height), Image.LANCZOS)
        self.tk_image = ImageTk.PhotoImage(self.image)
        
        # Configure canvas size
        self.canvas.config(width=new_width, height=new_height)
        
        # Create image on canvas
        self.canvas.create_image(0, 0, anchor="nw", image=self.tk_image)
        self.clear_rectangles()

    def set_aspect_ratio(self):
        aspect_ratio_input = simpledialog.askstring("Aspect Ratio", "Enter aspect ratio as 'width:height' (e.g., 16:9):")
        if aspect_ratio_input:
            try:
                width, height = map(float, aspect_ratio_input.split(':'))
                self.aspect_ratio = width / height
            except ValueError:
                self.aspect_ratio = None
                messagebox.showerror("Error", "Invalid aspect ratio format!")

    def on_button_press(self, event):
        self.start_x = event.x
        self.start_y = event.y
        self.end_x = event.x
        self.end_y = event.y
        self.draw_rectangle(self.start_x, self.start_y, self.end_x, self.end_y)

    def on_mouse_drag(self, event):
        self.end_x, self.end_y = self.adjust_aspect_ratio(event.x, event.y)
        self.canvas.coords(self.rect, self.start_x, self.start_y, self.end_x, self.end_y)

    def on_button_release(self, event):
        self.end_x, self.end_y = self.adjust_aspect_ratio(event.x, event.y)

    def draw_rectangle(self, x1, y1, x2, y2):
        if self.rect:
            self.canvas.delete(self.rect)
        self.rect = self.canvas.create_rectangle(x1, y1, x2, y2, outline=self.get_color(), width=2)

    def get_color(self):
        colors = ["red", "blue", "green", "orange", "purple"]
        return colors[self.crop_count % len(colors)]

    def adjust_aspect_ratio(self, x, y):
        if self.aspect_ratio:
            dx = x - self.start_x
            dy = y - self.start_y

            if abs(dx) > abs(dy):
                dy = dx / self.aspect_ratio
            else:
                dx = dy * self.aspect_ratio

            x = self.start_x + dx
            y = self.start_y + dy

        return x, y

    def crop_image(self):
        if self.image and self.rect:
            # Calculate the actual coordinates on the original image
            box = (
                int(min(self.start_x, self.end_x) / self.scaling_factor),
                int(min(self.start_y, self.end_y) / self.scaling_factor),
                int(max(self.start_x, self.end_x) / self.scaling_factor),
                int(max(self.start_y, self.end_y) / self.scaling_factor)
            )
            cropped_image = self.original_image.crop(box)

            # Generate the filename with the desired format
            filename = f"{self.crop_count+1:04d}_CroppedImage.png"
            
            save_path = filedialog.asksaveasfilename(
                defaultextension=".png",
                filetypes=[("PNG files", "*.png"), ("JPEG files", "*.jpg")],
                initialfile=filename
            )
            if save_path:
                cropped_image.save(save_path)
                self.add_crop_rectangle(self.start_x, self.start_y, self.end_x, self.end_y)
                self.crop_count += 1  # Increment the crop count after successful save

    def add_crop_rectangle(self, x1, y1, x2, y2):
        self.rectangles.append((x1, y1, x2, y2))
        self.canvas.create_rectangle(x1, y1, x2, y2, outline=self.get_color(), width=2)
        self.canvas.create_text((x1 + x2) / 2, (y1 + y2) / 2, text=str(self.crop_count + 1), fill=self.get_color())

    def clear_rectangles(self):
        for rect in self.rectangles:
            self.canvas.delete(rect)
        self.rectangles.clear()
        self.crop_count = 0

if __name__ == "__main__":
    root = tk.Tk()
    app = ImageCropper(root)
    root.mainloop()